package br.edu.etec.hortolandia.papercad.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import br.edu.etec.hortolandia.papercad.model.Midia;

public class MidiaDAO {

	/*
	 * Defini��o das informa��es necess�rias para conex�o a banco
	 */
	
	//Driver de conex�o ao MySQL
	private String servidor = "com.mysql.jdbc.Driver";
	//url que identifica o banco
	private String urlBanco = "jdbc:mysql://localhost:3306/papercad";
	//login de usu�rio no banco
	private String Banco = "root";
	//senha do usu�rio no banco
	private String senhaBanco = "root";
	//private String senhaBanco = "";
	
	//***M�todo de conexao
	public Connection conecta(){
		
		Connection con = null;
		
		try{
			
			Class.forName(servidor);
			con = DriverManager.getConnection(urlBanco, Banco, senhaBanco);
			
		}catch(ClassNotFoundException e){
			
			e.printStackTrace();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			
		}
		
		return con;
		
	}
	
	public void listar(){
		
		Connection con = conecta();
		
		try{
			
			Statement stmt = con.createStatement();
			String sql = "select * from midia";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			String relacao = "Rela��o das midias cadastradas \n";
			while(rs.next()){
				
				relacao = relacao + "\n Id: " + rs.getString(1).toString() + 
						" - Nome: " + rs.getString(2) + " - Descri��o: " + rs.getString(3) + 
						" - Tipo: " + rs.getString(4).toString() + " - Ativo: " + rs.getString(5).toString();
				
			}
			
			rs.close();
			JOptionPane.showMessageDialog(null, relacao + "\n");
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			
			try{
				
				con.close();
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
	}
	
	public Midia consultar(Midia mid){
		
		Connection con = conecta();
		try{
			
			Statement stmt = con.createStatement();
			String sql = "select * from midia where id = " + mid.getId();
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			try{
				
				mid.setId(rs.getInt(1));
				mid.setNome(rs.getString(2));
				mid.setDescricao(rs.getString(3));
				mid.setTipo(rs.getInt(4));
				mid.setAtivo(rs.getInt(5));
				
			}catch(Exception e){
				JOptionPane.showMessageDialog(null, "Midia n�o encontrada.");
			}
			
			rs.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			
			try{
				
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
			
			return mid;
		
		}
	
	public void incluir(Midia mid){
		
		Connection con = conecta();
		PreparedStatement ps = null;
		Statement stmt = null;
		
		try{
			
			stmt = con.createStatement();
			String sql = "select max(id) from midia";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			int proximoId = rs.getInt(1) + 1;
			rs.close();
			String sqlInsert = "insert into midia values(?, ?, ?, ?, ?);";
			ps = con.prepareStatement(sqlInsert);
			ps.setInt(1, proximoId);
			ps.setString(2, mid.getNome());
			ps.setString(3, mid.getDescricao());
			ps.setInt(4, mid.getTipo());
			ps.setInt(5, mid.getAtivo());
			ps.executeUpdate();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e,"Erro no SQL !!", 0);
			
		}finally{
			
			try{
				
				ps.close();
				stmt.close();
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, e,"Erro ao fechar conex�o !!", 0);
				
			}
			
		}
		
	}
	
	public void alterar(Midia mid){
		
		Connection con = conecta();
		PreparedStatement ps = null;
		
		try{
			
			String sqlUpdate = "update midia set nome = ?, descricao = ?, tipo = ?," + 
								" ativo = ? where id = ?;";
			ps = con.prepareStatement(sqlUpdate);
			ps.setString(1, mid.getNome());
			ps.setString(2, mid.getDescricao());
			ps.setString(3, Integer.toString(mid.getTipo()));
			ps.setString(4, Integer.toString(mid.getAtivo()));
			ps.setString(5, Integer.toString(mid.getId()));
			ps.executeUpdate();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			
		}finally{
			
			try{
				
				ps.close();
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
		
	}
	
	public void excluir(Midia mid){
		
		Connection con = conecta();
		PreparedStatement ps = null;
		
		try{
			
			String sqlDelete = "update midia set ativo = ? where id = ?;";
			
			ps = con.prepareStatement(sqlDelete);
			ps.setString(1, Integer.toString(mid.getAtivo()));
			ps.setString(2, Integer.toString(mid.getId()));
			ps.executeUpdate();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			
		}finally{
			
			try{
				
				ps.close();
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
		
	}
}
