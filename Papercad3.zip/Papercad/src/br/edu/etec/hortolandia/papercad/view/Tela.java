package br.edu.etec.hortolandia.papercad.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

import br.edu.etec.hortolandia.papercad.dao.MidiaDAO;
import br.edu.etec.hortolandia.papercad.dao.UsuarioDAO;
import br.edu.etec.hortolandia.papercad.model.Midia; 
import br.edu.etec.hortolandia.papercad.model.Usuario;

public class Tela extends JFrame implements ActionListener{  
  
    /** 
     *  
     */  
    private static final long serialVersionUID = 1L;
    JMenuBar menu;
	JMenu menuArquivo, menuGerenciar;
	JMenuItem miAjuda, miSobre, miSair, miLogoff, miUsuario;
    JLabel lId, lNome, lDescricao, lAtivo, lSim, lNao, lTipo, lAdm, lMod, lDef, lOutro;  
    JTextField txId, txNome;  
    JTextArea taDescricao;  
    JButton btInserir, btAlterar, btExcluir, btLocalizar, btLimpar, btListar, btConfirmar, btSair;  
    JRadioButton jrbAtivo1, jrbAtivo2, jrbAudioV, jrbVisual, jrbAudio, jrbOutro;  
    ButtonGroup bgGrupo1, bgGrupo2;  
    JScrollPane scroll;  

    Midia mid = new Midia();
    Usuario user = new Usuario();
    MidiaDAO conex = new MidiaDAO();
    UsuarioDAO use = new UsuarioDAO();
    
    int op = 0, tipo = 0, ativo = 0;  
    boolean checked, checked1, checked2;  
    String nome = "";
    
    public Tela(int ativo, int tipo, String nome){
		
		this.ativo = ativo;
    	this.tipo = tipo;  
    	this.nome = nome;
          
        this.setTitle("Papercad - Cadastro de M�dias de Comunica��o v0.01");  
        this.setSize(700,410);  
        this.setLayout(null);  
        this.setUndecorated(false);  
        this.setLocationRelativeTo(null);  
        getContentPane().setBackground(new Color(230,230,250));  
          
        Toolkit kit = Toolkit.getDefaultToolkit();  
    	Image img = kit.getImage("pen.png");
    	this.setIconImage(img);
          
        //Coluna, Linha , Largura e Altura  
        JLabel lId = new JLabel("Id: ");  
        lId.setBounds(10,10,80,20);  
        JLabel lNome = new JLabel("Nome: ");  
        lNome.setBounds(10,40,80,20);  
        JLabel lDescricao = new JLabel("Descricao:");  
        lDescricao.setBounds(390,10,80,20);  
        JLabel lAtivo = new JLabel("Registro Ativo");  
        lAtivo.setBounds(10, 160, 80, 20);  
        JLabel lSim = new JLabel("Sim");  
        lSim.setBounds(40, 190, 80, 20);  
        JLabel lNao = new JLabel("N�o");  
        lNao.setBounds(40, 210, 80, 20);  
        JLabel lTipo = new JLabel("Tipo de Midia");  
        lTipo.setBounds(190, 160, 100, 20);  
        JLabel lAdm = new JLabel("Audiovisual");  
        lAdm.setBounds(220, 190, 100, 20);  
        JLabel lMod = new JLabel("Visual");  
        lMod.setBounds(220, 210, 80, 20);  
        JLabel lDef = new JLabel("Audio");  
        lDef.setBounds(220, 230, 80, 20);  
        JLabel lOutro = new JLabel("Outro");  
        lOutro.setBounds(220, 250, 80, 20);  
          
        
		menu = new JMenuBar();
		
		menuArquivo = new JMenu("Arquivo");
		menuArquivo.setMnemonic(KeyEvent.VK_A);
		menuArquivo.addActionListener(this);
		
		menuGerenciar = new JMenu("Gerenciar");
		menuGerenciar.setMnemonic(KeyEvent.VK_G);
		menuGerenciar.addActionListener(this);
		
		miAjuda = new JMenuItem("Ajuda", new ImageIcon("ajuda.png"));
		miAjuda.addActionListener(this);
		miAjuda.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,ActionEvent.CTRL_MASK));
		miAjuda.setMnemonic(KeyEvent.VK_J);
        
		miSobre = new JMenuItem("Sobre", new ImageIcon("sobre.png"));
		miSobre.addActionListener(this);
		miSobre.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.CTRL_MASK));
		miSobre.setMnemonic(KeyEvent.VK_S);
        
		miLogoff = new JMenuItem("Logoff", new ImageIcon("logoff.png"));
		miLogoff.addActionListener(this);
		miLogoff.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,ActionEvent.ALT_MASK));
		miLogoff.setMnemonic(KeyEvent.VK_L);
        
		miSair = new JMenuItem("Sair", new ImageIcon("sair.png"));
		miSair.addActionListener(this);
		miSair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,ActionEvent.ALT_MASK));
		miSair.setMnemonic(KeyEvent.VK_X);
		
		miUsuario = new JMenuItem("Usuario", new ImageIcon("user.png"));
		miUsuario.addActionListener(this);
		miUsuario.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U,ActionEvent.CTRL_MASK));
		miUsuario.setMnemonic(KeyEvent.VK_U);
		
		
		menuArquivo.add(miAjuda);
		menuArquivo.add(miSobre);
		menuArquivo.add(miLogoff);
		menuArquivo.add(miSair);
		
		menuGerenciar.add(miUsuario);
		
		
		setJMenuBar(menu);
		
        txId = new JTextField();  
        txId.setBounds(80,10,270,20);  
        txNome = new JTextField();  
        txNome.setBounds(80,40,270,20);  
          
        taDescricao = new JTextArea();  
        //Estes dois atributos fazem com que voc� n�o se preocupe com a dire��o da barra do scroll  
        taDescricao.setLineWrap(true);//Este faz com que a linha quebre cada vez que se atingir o fim da linha  
        taDescricao.setWrapStyleWord(true);//Este faz com que as palavras n�o sejam divididas, tipo... na palavra "palavras" o "p" fica numa linha e "alavra" na outra  
        taDescricao.setBounds(390,30,270,250);  
          
  
        scroll = new JScrollPane(taDescricao);      
        scroll.setSize(new Dimension (450, 110));      
        scroll.setVisible(true);      
        scroll.setBounds(390, 30, 280, 250);  
          
        jrbAtivo1 = new JRadioButton ();  
        jrbAtivo1.setBounds(20, 190, 20, 20);  
        jrbAtivo1.setSelected (true);  
        jrbAtivo1.addActionListener(this);  
        jrbAtivo2 = new JRadioButton ();  
        jrbAtivo2.setBounds(20, 210, 20, 20);  
        jrbAtivo2.setSelected (false);  
        jrbAtivo2.addActionListener(this);  
        jrbAudioV = new JRadioButton ();  
        jrbAudioV.setBounds(200, 190, 20, 20);  
        jrbAudioV.setSelected (false);  
        jrbAudioV.addActionListener(this);  
        jrbVisual = new JRadioButton ();  
        jrbVisual.setBounds(200, 210, 20, 20);  
        jrbVisual.setSelected (false);  
        jrbVisual.addActionListener(this);  
        jrbAudio = new JRadioButton ();  
        jrbAudio.setBounds(200, 230, 20, 20);  
        jrbAudio.setSelected (true);  
        jrbAudio.addActionListener(this);  
        jrbOutro = new JRadioButton();  
        jrbOutro.setBounds(200, 250, 20, 20);  
        jrbOutro.setSelected(false);  
        jrbOutro.addActionListener(this);  
          
        bgGrupo1 = new ButtonGroup();  
        bgGrupo1.add(jrbAtivo1);  
        bgGrupo1.add(jrbAtivo2);  
        bgGrupo2 = new ButtonGroup();  
        bgGrupo2.add(jrbAudioV);  
        bgGrupo2.add(jrbVisual);  
        bgGrupo2.add(jrbAudio);  
        bgGrupo2.add(jrbOutro);  
          
        btInserir = new JButton("Inserir");  
        btInserir.setBounds(10,290,100,20);  
        btInserir.addActionListener(this);  
        btAlterar = new JButton("Alterar");  
        btAlterar.setBounds(120,290,100,20);  
        btAlterar.addActionListener(this);  
        btAlterar.setEnabled(false);  
        btExcluir = new JButton("Excluir");  
        btExcluir.setBounds(230,290,100,20);  
        btExcluir.addActionListener(this);  
        btExcluir.setEnabled(false);  
        btLocalizar = new JButton("Localizar");  
        btLocalizar.setBounds(340,290,100,20);  
        btLocalizar.addActionListener(this);  
        btLimpar = new JButton("Limpar");  
        btLimpar.setBounds(450,290,100,20);  
        btLimpar.addActionListener(this);  
        btListar = new JButton("Listar");  
        btListar.setBounds(560,290,100,20);  
        btListar.addActionListener(this);  
        btConfirmar = new JButton("Confirmar");  
        btConfirmar.setBounds(230,320,100,20);  
        btConfirmar.addActionListener(this);  
        btSair = new JButton("Sair");  
        btSair.setBounds(340,320,100,20);  
        btSair.addActionListener(this);  
          
		if(ativo == 0){
    		
    		JOptionPane.showMessageDialog(null, "Login e/ou senha incorretos !!", "Erro...", JOptionPane.WARNING_MESSAGE);
    		this.dispose();
    		new Login();
    		
    	}else{
    		
    		JOptionPane.showMessageDialog(null, "Seja bem-vindo "+nome+".","Seja Bem-Vindo",JOptionPane.INFORMATION_MESSAGE);
    		
    		if(tipo == 2){
    			
    			/*txId.setEnabled(true);
    			taDescricao.setEnabled(false);
    			txNome.setEnabled(false);
    			
    			jrbAudioV.setEnabled(false);
    			jrbAtivo1.setEnabled(false);
    			jrbAtivo2.setEnabled(false);
    			jrbAudio.setEnabled(false);
    			jrbVisual.setEnabled(false);
    			jrbOutro.setEnabled(false);    			
    			
    			btAlterar.setEnabled(false);
    			btExcluir.setEnabled(false);
    			btInserir.setEnabled(false);
    			btListar.setEnabled(true);
    			btLocalizar.setEnabled(true);
    			
    			taDescricao.setText("");
    			txId.setText("");
    			txNome.setText("");
    			
    			menuGerenciar.setEnabled(false);*/
    			
    			this.add(lId);  
    	        this.add(lNome);  
    	        this.add(lDescricao);  
    	        this.add(txId);  
    	        this.add(txNome);
    	        this.add(btLocalizar);  
    	        this.add(btLimpar);  
    	        this.add(btListar);  
    	        this.add(btConfirmar);  
    	        this.add(btSair);  
    	        this.add(jrbAtivo1);  
    	        this.add(jrbAtivo2);  
    	        this.add(lAtivo);  
    	        this.add(lSim);  
    	        this.add(lNao);  
    	        this.add(jrbAudioV);  
    	        this.add(jrbVisual);  
    	        this.add(jrbAudio);  
    	        this.add(lTipo);  
    	        this.add(lAdm);  
    	        this.add(lMod);  
    	        this.add(lDef);
    	        this.add(lOutro);  
    	        this.add(jrbOutro);  
    	        this.add(scroll);
    	        
    	        menu.add(menuArquivo);
    			//menu.add(menuGerenciar);
    			
    		}else{if(tipo ==  1){
    			
    			/*txId.setEnabled(true);
    			taDescricao.setEnabled(true);
    			txNome.setEnabled(true);
    			
    			jrbAudioV.setEnabled(true);
    			jrbAtivo1.setEnabled(true);
    			jrbAtivo2.setEnabled(true);
    			jrbAudio.setEnabled(true);
    			jrbVisual.setEnabled(true);
    			jrbOutro.setEnabled(true);
    			
    			btAlterar.setEnabled(false);
    			btExcluir.setEnabled(false);
    			btInserir.setEnabled(true);
    			btListar.setEnabled(true);
    			btLocalizar.setEnabled(true);
    			
    			taDescricao.setText("");
    			txId.setText("");
    			txNome.setText("");
    			
    			menuGerenciar.setEnabled(false);*/
    			
    			this.add(lId);  
                this.add(lNome);  
                this.add(lDescricao);  
                this.add(txId);  
                this.add(txNome);   
                this.add(btInserir);  
                this.add(btAlterar);  
                this.add(btExcluir);  
                this.add(btLocalizar);  
                this.add(btLimpar);  
                this.add(btListar);  
                this.add(btConfirmar);  
                this.add(btSair);  
                this.add(jrbAtivo1);  
                this.add(jrbAtivo2);  
                this.add(lAtivo);  
                this.add(lSim);  
                this.add(lNao);  
                this.add(jrbAudioV);  
                this.add(jrbVisual);  
                this.add(jrbAudio);  
                this.add(lTipo);  
                this.add(lAdm);  
                this.add(lMod);  
                this.add(lDef);
                this.add(lOutro);  
                this.add(jrbOutro);  
                this.add(scroll);
                
                menu.add(menuArquivo);
    			//menu.add(menuGerenciar);
    		}else{
    			
    			this.add(lId);  
                this.add(lNome);  
                this.add(lDescricao);  
                this.add(txId);  
                this.add(txNome);   
                this.add(btInserir);  
                this.add(btAlterar);  
                this.add(btExcluir);  
                this.add(btLocalizar);  
                this.add(btLimpar);  
                this.add(btListar);  
                this.add(btConfirmar);  
                this.add(btSair);  
                this.add(jrbAtivo1);  
                this.add(jrbAtivo2);  
                this.add(lAtivo);  
                this.add(lSim);  
                this.add(lNao);  
                this.add(jrbAudioV);  
                this.add(jrbVisual);  
                this.add(jrbAudio);  
                this.add(lTipo);  
                this.add(lAdm);  
                this.add(lMod);  
                this.add(lDef);
                this.add(lOutro);  
                this.add(jrbOutro);  
                this.add(scroll);
                
                menu.add(menuArquivo);
    			menu.add(menuGerenciar);
    			
    		}
    		}
    	}
          
        this.setVisible(true);  
          
    }
    
    
    
	public void actionPerformed(ActionEvent e) { 	
    	
    	if(e.getSource() == miAjuda){
    		
    		JOptionPane.showMessageDialog(null, "Para usar o Papercad - Cadastro de M�dias de Comunica��o v0.01, " +
    				"basta selecionar a op��o, \n" +
    				"preencher os campos se solicitado e apertar confirmar.\n\n" +
    				"Em caso de d�vidas basta entrar em contato com o administrador.\n\n", "Ajuda",JOptionPane.WARNING_MESSAGE, new ImageIcon("ajuda.png"));
    		
    	}
    	
    	if(e.getSource() == miSobre){
    		
    		JOptionPane.showMessageDialog(null, "Papercad - Cadastro de M�dias de Comunica��o v0.01\n\n" +
    				"Desenvolvido por Vin�cius Savi Silva.\n" +
    				"Contato: raytek.net@gmail.com\n\n", "Sobre",JOptionPane.WARNING_MESSAGE, new ImageIcon("sobre.png"));
    		
    	}
    	
    	if(e.getSource() == miLogoff){
    		
    		int resposta = JOptionPane.showConfirmDialog(null,"Deseja efetuar logoff?", "Logoff",JOptionPane.WARNING_MESSAGE, JOptionPane.YES_NO_OPTION, new ImageIcon("logoff.png"));  
			if(resposta == JOptionPane.YES_OPTION){ 
				new Login();
				this.dispose();
			}
    		
    	}
    	
    	if(e.getSource() == miSair){
    		
    		int resposta = JOptionPane.showConfirmDialog(null,"Deseja sair?", "Sair",JOptionPane.WARNING_MESSAGE, JOptionPane.YES_NO_OPTION, new ImageIcon("sair.png"));  
			if(resposta == JOptionPane.YES_OPTION){ 
				System.exit(0);
			}
    		
    	}
    	
    	if(e.getSource() == miUsuario){
    		
    		this.setExtendedState(JFrame.ICONIFIED);
    		new Formulario();
    		this.setExtendedState((int) JFrame.CENTER_ALIGNMENT);
    		
    	}
    	
    	
//-------------------INICIO DO BOT�O INSERIR-------------------		
		
		if(e.getSource() == btInserir){
			
			op = 1;
			
			txId.setEnabled(false);
			
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O INSERIR-------------------
		
//-------------------INICIO DO BOT�O LOCALIZAR-------------------
		
		if(e.getSource() == btLocalizar){
			
			op = 2;
			
			txId.setEnabled(true);
			taDescricao.setEnabled(false);
			txNome.setEnabled(false);
			
			jrbAudioV.setEnabled(false);
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			jrbAudio.setEnabled(false);
			jrbVisual.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O LOCALIZAR-------------------	
		
//-------------------INICIO DE BOT�O LISTAR-------------------		
		
		if(e.getSource() == btListar){
			
			op = 3;
			
			txId.setEnabled(false);
			taDescricao.setEnabled(false);
			txNome.setEnabled(false);
			
			jrbAudioV.setEnabled(false);
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			jrbAudio.setEnabled(false);
			jrbVisual.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O LISTAR-------------------		
		
//-------------------INICIO DO BOT�O ALTERAR-------------------
		
		if(e.getSource() == btAlterar){
			
			op = 4;
			
			txId.setEnabled(false);
			taDescricao.setEnabled(true);
			txNome.setEnabled(true);
			
			jrbAudioV.setEnabled(true);
			jrbAtivo1.setEnabled(true);
			jrbAtivo2.setEnabled(true);
			jrbAudio.setEnabled(true);
			jrbVisual.setEnabled(true);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O ALTERAR-------------------	
		
//-------------------INICIO DO BOT�O EXCLUIR-------------------		
		
		if(e.getSource() == btExcluir){
			
			op = 5;
			
			txId.setEnabled(false);
			taDescricao.setEnabled(false);
			txNome.setEnabled(false);
			
			jrbAudioV.setEnabled(false);
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			jrbAudio.setEnabled(false);
			jrbVisual.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O EXCLUIR-------------------		
		
//-------------------INICIO DO BOT�O LIMPAR-------------------		
		
		if(e.getSource() == btLimpar){
			
			op = 0;
			
			txId.setEnabled(true);
			taDescricao.setEnabled(true);
			txNome.setEnabled(true);
			
			jrbAudioV.setEnabled(true);
			jrbAtivo1.setEnabled(true);
			jrbAtivo2.setEnabled(true);
			jrbAudio.setEnabled(true);
			jrbVisual.setEnabled(true);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(true);
			btListar.setEnabled(true);
			btLocalizar.setEnabled(true);
			
			taDescricao.setText("");
			txId.setText("");
			txNome.setText("");
			
		}
		
//-------------------FIM DO BOT�O LIMPAR-------------------		
		
//-------------------INICIO DO BOT�O SAIR-------------------		
		
		if(e.getSource() == btSair){
			
    		int resposta = JOptionPane.showConfirmDialog(null,"Deseja sair?", "Sair",JOptionPane.WARNING_MESSAGE, JOptionPane.YES_NO_OPTION, new ImageIcon("sair.png"));  
			if(resposta == JOptionPane.YES_OPTION){ 
				System.exit(0);
			}
			
		}
		
//-------------------FIM DO BOT�O SAIR-------------------
		
//-------------------iNICIO DO BOT�O CONFIRMAR-------------------		
		
		if(e.getSource() == btConfirmar){
		
		switch(op){

		//***ROTINA DE INSER��O DE UM NOVO REGISTRO***
		
		case 1:
			
			//Le os campos do formulario e carrega o objeto aluno
			mid.setNome(txNome.getText());
			mid.setAtivo(1);
			mid.setDescricao(taDescricao.getText());
			
			checked = jrbAudioV.isSelected();
			checked1 = jrbVisual.isSelected();
			checked2 = jrbAudio.isSelected();
			
			if(checked == true){
				
				mid.setTipo(0);
				
			}else{
				
				if(checked1 == true){
					
					mid.setTipo(1);
					
				}else{
					
					if(checked2 == true){
						
						mid.setTipo(2);
						
					}else{mid.setTipo(3);}
					
				}
				
			}
			
			/*
			 * Passa o objeto aluno por parametro para o metodo Incluir
			 * do objeto conex (AlunoBD)
			 */
			conex.incluir(mid);
			
			JOptionPane.showMessageDialog(null, "Inclus�o realizada com sucesso !!",
					"Confirma��o", JOptionPane.INFORMATION_MESSAGE);break;
			
		//***FIM DA ROTINA DE INSER��O DE UM NOVO REGISTRO***
		
		//***ROTINA DE CONSULTA DE UM REGISTRO
					
		case 2:			
			
			Midia midiaConsulta = new Midia();
			
			mid.setId(Integer.parseInt(txId.getText()));
			
			midiaConsulta = conex.consultar(mid);
			
			txNome.setText(midiaConsulta.getNome());
			taDescricao.setText(midiaConsulta.getDescricao());
			
			boolean b = true;
			
			if(midiaConsulta.getTipo() == 0){
				
				jrbAudioV.setSelected(b);
				
			}else{
				
				if(midiaConsulta.getTipo() == 1){
					
					jrbVisual.setSelected(b);
					
				}else{
					
					if(midiaConsulta.getTipo() == 2){
						
						jrbAudio.setSelected(b);
						
					}else{jrbOutro.setSelected(b);}
					
				}
				
			}
			
			if(midiaConsulta.getAtivo() == 0){
				
				jrbAtivo2.setSelected(b);
				
			}else{
				
				jrbAtivo1.setSelected(b);
				btExcluir.setEnabled(true);
			
			}
			
			btAlterar.setEnabled(true);break;
		
		//***FIM DA ROTINA DE CONSULTA DE UM REGISTRO***
					
		//***ROTINA DE LISTAGEM DO BANCO***
			
		case 3:
			
			conex.listar();break;
			
		//***FIM DA ROTINA DE LISTAGEM DO BANCO***	
			
		//***ROTINA DE ALTERA��O DE UM REGISTRO***
			
		case 4:
			
			mid.setNome(txNome.getText());
			mid.setDescricao(taDescricao.getText());
			
			boolean testeAudioV = jrbAudioV.isSelected();
			boolean testeVisual = jrbVisual.isSelected();
			boolean testeAudio = jrbAudio.isSelected();
			
			if(testeAudioV == true){
				
				mid.setTipo(0);
				
			}else{
				
				if(testeVisual == true){
					
					mid.setTipo(1);
					
				}else{
					
					if(testeAudio ==true){
						
						mid.setTipo(2);
						
					}else{mid.setTipo(3);}
					
				}}
				
			boolean testeAtivo = jrbAtivo1.isSelected();
			
			if(testeAtivo == true){
				
				mid.setAtivo(1);
				
			}else{mid.setAtivo(0);}

			
			conex.alterar(mid);
			
			JOptionPane.showMessageDialog(null, "Altera��o realizada com sucesso!!",
					"Confirma��o", JOptionPane.INFORMATION_MESSAGE);break;
					
		//***FIM DA ROTINA DE ALTERA��O DE UM REGISTRO***	
					
		//***INICIO DA ROTINA DE EXCLUS�O DE REGISTRO***
					
		case 5:
			
			int opcao = JOptionPane.showConfirmDialog(null,"Tem certaza que deseja excluir o registro?", "Alerta",JOptionPane.WARNING_MESSAGE, JOptionPane.YES_NO_OPTION);  
			if(opcao == JOptionPane.YES_OPTION){
			
				mid.setAtivo(0);
				conex.excluir(mid);
				JOptionPane.showMessageDialog(null, "Registro excluido com sucesso!!","Comfirma��o", JOptionPane.INFORMATION_MESSAGE);
				
				
				
			}else{JOptionPane.showMessageDialog(null, "Nenhum registro foi excluido!!","Comfirma��o", JOptionPane.INFORMATION_MESSAGE);}break;
					
		//***FIM DA ROTINA DE EXCLUS�O DE REGISTRO***		
			
		//***INICIO OP��O PADR�O***	
			
		default:
			
			JOptionPane.showMessageDialog(null, "Op��o Inv�lida. \n\n Favor entrar com uma op��o v�lida!!","Comfirma��o", JOptionPane.INFORMATION_MESSAGE);break;
			
		//***FIM DA OP��O PADR�O***	
			
		}
		
	}
		
//-------------------FIM DO BOT�O CONFIRMAR-------------------		
		
	}
    	
 //   }	
	
}
