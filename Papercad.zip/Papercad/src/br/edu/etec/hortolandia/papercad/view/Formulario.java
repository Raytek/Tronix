package br.edu.etec.hortolandia.papercad.view;



import java.awt.*;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import br.edu.etec.hortolandia.papercad.dao.UsuarioDAO;
import br.edu.etec.hortolandia.papercad.model.Usuario;


public class Formulario extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel lId, lNome, lSenha, lLogin, lEmail, lAtivo, lSim, lNao, lTipo, lAdm, lMod, lDef, imagem2;
	JTextField txId, txNome, txLogin, txEmail;
	JPasswordField  txSenha;
	JButton btInserir, btAlterar, btExcluir, btLocalizar, btLimpar, btListar, btConfirmar, btSair;
	JRadioButton jrbAtivo1, jrbAtivo2, jrbAdm, jrbMod, jrbDef;
	ButtonGroup bgGrupo1, bgGrupo2;
	ImageIcon imagem;
	
	Usuario user = new Usuario();
	UsuarioDAO conex = new UsuarioDAO();
	
	public Formulario(){
		
		this.setTitle("Cadastro de Usuarios");
		this.setSize(700,350);
		this.setLayout(null);
		this.setUndecorated(true);
		this.setLocationRelativeTo(null);
		getContentPane().setBackground(new Color(230,230,250));
		
        Toolkit kit = Toolkit.getDefaultToolkit();  
    	Image img = kit.getImage("pen.png");
    	this.setIconImage(img);

		imagem = new ImageIcon("text.png");
		imagem2 = new JLabel(imagem);
		imagem2.setBounds(400, 10, 200, 200);
    	
		//Coluna, Linha , Largura e Altura
		JLabel lId = new JLabel("Id: ");
		lId.setBounds(10,10,80,20);
		JLabel lNome = new JLabel("Nome: ");
		lNome.setBounds(10,30,80,20);
		JLabel lLogin = new JLabel("Login: ");
		lLogin.setBounds(10,50,80,20);
		JLabel lSenha = new JLabel("Senha: ");
		lSenha.setBounds(10,70,80,20);
		JLabel lEmail = new JLabel("E-mail: ");
		lEmail.setBounds(10,90,80,20);
		JLabel lAtivo = new JLabel("Registro Ativo");
		lAtivo.setBounds(10, 120, 80, 20);
		JLabel lSim = new JLabel("Sim");
		lSim.setBounds(40, 150, 80, 20);
		JLabel lNao = new JLabel("N�o");
		lNao.setBounds(40, 170, 80, 20);
		JLabel lTipo = new JLabel("Tipo de Usu�rio");
		lTipo.setBounds(100, 120, 100, 20);
		JLabel lAdm = new JLabel("Adminidtrador");
		lAdm.setBounds(120, 150, 100, 20);
		JLabel lMod = new JLabel("Moderador");
		lMod.setBounds(120, 170, 80, 20);
		JLabel lDef = new JLabel("Padr�o");
		lDef.setBounds(120, 190, 80, 20);
		
		txId = new JTextField();
		txId.setBounds(80,10,270,20);
		txNome = new JTextField();
		txNome.setBounds(80,30,270,20);
		txLogin = new JTextField();
		txLogin.setBounds(80,50,270,20);
		txSenha = new JPasswordField();
		txSenha.setBounds(80,70,270,20);
		txEmail = new JTextField();
		txEmail.setBounds(80,90,270,20);
		
		jrbAtivo1 = new JRadioButton ();
		jrbAtivo1.setBounds(20, 150, 20, 20);
		jrbAtivo1.setSelected (true);
		jrbAtivo1.addActionListener(this);
		jrbAtivo2 = new JRadioButton ();
		jrbAtivo2.setBounds(20, 170, 20, 20);
		jrbAtivo2.setSelected (false);
		jrbAtivo2.addActionListener(this);
		jrbAdm = new JRadioButton ();
		jrbAdm.setBounds(100, 150, 20, 20);
		jrbAdm.setSelected (false);
		jrbAdm.addActionListener(this);
		jrbMod = new JRadioButton ();
		jrbMod.setBounds(100, 170, 20, 20);
		jrbMod.setSelected (false);
		jrbMod.addActionListener(this);
		jrbDef = new JRadioButton ();
		jrbDef.setBounds(100, 190, 20, 20);
		jrbDef.setSelected (true);
		jrbDef.addActionListener(this);
		
		bgGrupo1 = new ButtonGroup();
	    bgGrupo1.add(jrbAtivo1);
	    bgGrupo1.add(jrbAtivo2);
	    bgGrupo2 = new ButtonGroup();
	    bgGrupo2.add(jrbAdm);
	    bgGrupo2.add(jrbMod);
	    bgGrupo2.add(jrbDef);
		
		btInserir = new JButton("Inserir");
		btInserir.setBounds(10,210,100,20);
		btInserir.addActionListener(this);
		btAlterar = new JButton("Alterar");
		btAlterar.setBounds(120,210,100,20);
		btAlterar.addActionListener(this);
		btAlterar.setEnabled(false);
		btExcluir = new JButton("Excluir");
		btExcluir.setBounds(230,210,100,20);
		btExcluir.addActionListener(this);
		btExcluir.setEnabled(false);
		btLocalizar = new JButton("Localizar");
		btLocalizar.setBounds(340,210,100,20);
		btLocalizar.addActionListener(this);
		btLimpar = new JButton("Limpar");
		btLimpar.setBounds(450,210,100,20);
		btLimpar.addActionListener(this);
		btListar = new JButton("Listar");
		btListar.setBounds(560,210,100,20);
		btListar.addActionListener(this);
		btConfirmar = new JButton("Confirmar");
		btConfirmar.setBounds(230,240,100,20);
		btConfirmar.addActionListener(this);
		btSair = new JButton("Sair");
		btSair.setBounds(340,240,100,20);
		btSair.addActionListener(this);
		
		this.add(lId);
		this.add(lNome);
		this.add(lSenha);
		this.add(lEmail);
		this.add(lLogin);
		this.add(txId);
		this.add(txNome);
		this.add(txLogin);
		this.add(txSenha);
		this.add(txEmail);
		this.add(btInserir);
		this.add(btAlterar);
		this.add(btExcluir);
		this.add(btLocalizar);
		this.add(btLimpar);
		this.add(btListar);
		this.add(btConfirmar);
		this.add(btSair);
		this.add(jrbAtivo1);
		this.add(jrbAtivo2);
		this.add(lAtivo);
		this.add(lSim);
		this.add(lNao);
		this.add(jrbAdm);
		this.add(jrbMod);
		this.add(jrbDef);
		this.add(lTipo);
		this.add(lAdm);
		this.add(lMod);
		this.add(lDef);
		this.add(imagem2);
		
		this.setVisible(true);
		
	}
	
	int op = 0;
	boolean checked, checked1;
	
	public void actionPerformed(ActionEvent e) {

//-------------------INICIO DO BOT�O INSERIR-------------------		
		
		if(e.getSource() == btInserir){
			
			op = 1;
			
			txId.setEnabled(false);
			
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O INSERIR-------------------
		
//-------------------INICIO DO BOT�O LOCALIZAR-------------------
		
		if(e.getSource() == btLocalizar){
			
			op = 2;
			
			txId.setEnabled(true);
			txEmail.setEnabled(false);
			txLogin.setEnabled(false);
			txNome.setEnabled(false);
			txSenha.setEnabled(false);
			
			jrbAdm.setEnabled(false);
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			jrbDef.setEnabled(false);
			jrbMod.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O LOCALIZAR-------------------	
		
//-------------------INICIO DE BOT�O LISTAR-------------------		
		
		if(e.getSource() == btListar){
			
			op = 3;
			
			txId.setEnabled(false);
			txEmail.setEnabled(false);
			txLogin.setEnabled(false);
			txNome.setEnabled(false);
			txSenha.setEnabled(false);
			
			jrbAdm.setEnabled(false);
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			jrbDef.setEnabled(false);
			jrbMod.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O LISTAR-------------------		
		
//-------------------INICIO DO BOT�O ALTERAR-------------------
		
		if(e.getSource() == btAlterar){
			
			op = 4;
			
			txId.setEnabled(false);
			txEmail.setEnabled(true);
			txLogin.setEnabled(true);
			txNome.setEnabled(true);
			txSenha.setEnabled(true);
			
			jrbAdm.setEnabled(true);
			jrbAtivo1.setEnabled(true);
			jrbAtivo2.setEnabled(true);
			jrbDef.setEnabled(true);
			jrbMod.setEnabled(true);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O ALTERAR-------------------	
		
//-------------------INICIO DO BOT�O EXCLUIR-------------------		
		
		if(e.getSource() == btExcluir){
			
			op = 5;
			
			txId.setEnabled(false);
			txEmail.setEnabled(false);
			txLogin.setEnabled(false);
			txNome.setEnabled(false);
			txSenha.setEnabled(false);
			
			jrbAdm.setEnabled(false);
			jrbAtivo1.setEnabled(false);
			jrbAtivo2.setEnabled(false);
			jrbDef.setEnabled(false);
			jrbMod.setEnabled(false);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(false);
			btListar.setEnabled(false);
			btLocalizar.setEnabled(false);
			
		}
		
//-------------------FIM DO BOT�O EXCLUIR-------------------		
		
//-------------------INICIO DO BOT�O LIMPAR-------------------		
		
		if(e.getSource() == btLimpar){
			
			op = 0;
			
			txId.setEnabled(true);
			txEmail.setEnabled(true);
			txLogin.setEnabled(true);
			txNome.setEnabled(true);
			txSenha.setEnabled(true);
			
			jrbAdm.setEnabled(true);
			jrbAtivo1.setEnabled(true);
			jrbAtivo2.setEnabled(true);
			jrbDef.setEnabled(true);
			jrbMod.setEnabled(true);
			
			btAlterar.setEnabled(false);
			btExcluir.setEnabled(false);
			btInserir.setEnabled(true);
			btListar.setEnabled(true);
			btLocalizar.setEnabled(true);
			
			txEmail.setText("");
			txLogin.setText("");
			txId.setText("");
			txNome.setText("");
			txSenha.setText("");
			
		}
		
//-------------------FIM DO BOT�O LIMPAR-------------------		
		
//-------------------INICIO DO BOT�O SAIR-------------------		
		
		if(e.getSource() == btSair){
			
			System.exit(0);
			
		}
		
//-------------------FIM DO BOT�O SAIR-------------------
		
//-------------------iNICIO DO BOT�O CONFIRMAR-------------------		
		
		if(e.getSource() == btConfirmar){
		
		switch(op){

		//***ROTINA DE INSER��O DE UM NOVO REGISTRO***
		
		case 1:
			
			//Le os campos do formulario e carrega o objeto aluno
			user.setNome(txNome.getText());
			user.setLogin(txLogin.getText());
			user.setSenha(txSenha.getText());
			user.setEmail(txEmail.getText());
			user.setAtivo(1);
			
			checked = jrbAdm.isSelected();
			checked1 = jrbMod.isSelected();
			
			if(checked == true){
				
				user.setTipo(0);
				
			}else{
				
				if(checked1 == true){
					
					user.setTipo(1);
					
				}else{user.setTipo(2);}
				
			}
			
			/*
			 * Passa o objeto aluno por parametro para o metodo Incluir
			 * do objeto conex (AlunoBD)
			 */
			conex.incluir(user);
			
			JOptionPane.showMessageDialog(null, "Inclus�o realizada com sucesso !!",
					"Confirma��o", JOptionPane.INFORMATION_MESSAGE);break;
			
		//***FIM DA ROTINA DE INSER��O DE UM NOVO REGISTRO***
		
		//***ROTINA DE CONSULTA DE UM REGISTRO
					
		case 2:			
			
			Usuario usuarioConsulta = new Usuario();
			
			user.setId(Integer.parseInt(txId.getText()));
			
			usuarioConsulta = conex.consultar(user);
			
			txNome.setText(usuarioConsulta.getNome());
			txLogin.setText(usuarioConsulta.getLogin());
			txSenha.setText(usuarioConsulta.getSenha());
			txEmail.setText(usuarioConsulta.getEmail());
			
			boolean b = true;
			
			if(usuarioConsulta.getTipo() == 0){
				
				jrbAdm.setSelected(b);
				
			}else{
				
				if(usuarioConsulta.getTipo() == 1){
					
					jrbMod.setSelected(b);
					
				}else{jrbDef.setSelected(b);}
				
			}
			
			if(usuarioConsulta.getAtivo() == 0){
				
				jrbAtivo2.setSelected(b);
				
			}else{
				
				jrbAtivo1.setSelected(b);
				btExcluir.setEnabled(true);
			
			}
			
			btAlterar.setEnabled(true);break;
		
		//***FIM DA ROTINA DE CONSULTA DE UM REGISTRO***
					
		//***ROTINA DE LISTAGEM DO BANCO***
			
		case 3:
			
			conex.listar();break;
			
		//***FIM DA ROTINA DE LISTAGEM DO BANCO***	
			
		//***ROTINA DE ALTERA��O DE UM REGISTRO***
			
		case 4:
			
			user.setNome(txNome.getText());
			user.setLogin(txLogin.getText());
			user.setSenha(txSenha.getText());
			user.setEmail(txEmail.getText());
			
			boolean testeAdm = jrbAdm.isSelected();
			boolean testeMod = jrbMod.isSelected();
			
			if(testeAdm == true){
				
				user.setTipo(0);
				
			}else{
				
				if(testeMod == true){
					
					user.setTipo(1);
					
				}else{user.setTipo(2);}}
				
			boolean testeAtivo = jrbAtivo1.isSelected();
			
			if(testeAtivo == true){
				
				user.setAtivo(1);
				
			}else{user.setAtivo(0);}

			
			conex.alterar(user);
			
			JOptionPane.showMessageDialog(null, "Altera��o realizada com sucesso!!",
					"Confirma��o", JOptionPane.INFORMATION_MESSAGE);break;
					
		//***FIM DA ROTINA DE ALTERA��O DE UM REGISTRO***	
					
		//***INICIO DA ROTINA DE EXCLUS�O DE REGISTRO***
					
		case 5:
			
			int opcao = JOptionPane.showConfirmDialog(null,"Tem certaza que deseja excluir o registro?", "Alerta",JOptionPane.WARNING_MESSAGE, JOptionPane.YES_NO_OPTION);  
			if(opcao == JOptionPane.YES_OPTION){
			
				user.setAtivo(0);
				conex.excluir(user);
				JOptionPane.showMessageDialog(null, "Registro excluido com sucesso!!","Comfirma��o", JOptionPane.INFORMATION_MESSAGE);
				
				
				
			}else{JOptionPane.showMessageDialog(null, "Nenhum registro foi excluido!!","Comfirma��o", JOptionPane.INFORMATION_MESSAGE);}break;
					
		//***FIM DA ROTINA DE EXCLUS�O DE REGISTRO***		
			
		//***INICIO OP��O PADR�O***	
			
		default:
			
			JOptionPane.showMessageDialog(null, "Op��o Inv�lida. \n\n Favor entrar com uma op��o v�lida!!","Comfirma��o", JOptionPane.INFORMATION_MESSAGE);break;
			
		//***FIM DA OP��O PADR�O***	
			
		}
		
	}
		
//-------------------FIM DO BOT�O CONFIRMAR-------------------		
		
	}
}