package br.edu.etec.hortolandia.papercad.model;
public class Midia {

}
