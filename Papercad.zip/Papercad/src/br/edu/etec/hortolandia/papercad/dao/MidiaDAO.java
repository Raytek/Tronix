package br.edu.etec.hortolandia.papercad.dao;
public class MidiaDAO {

}
