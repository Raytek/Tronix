package br.edu.etec.hortolandia.papercad.main;

import br.edu.etec.hortolandia.papercad.view.Login;
//import br.edu.etec.hortolandia.papercad.view.Tela;


public class Principal {
	
	public static void main(String[] args) {
		
		new Login();
	}

}