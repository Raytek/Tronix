package br.edu.etec.hortolandia.papercad.model;

//-----------------------------------CLASSE MODELO USUARIO-----------------------------------

public class Midia {
	
//-----------------------------------ATRIBUTOS-----------------------------------	
	
	private String nome, descricao;
	private int id, tipo, ativo;
	
//-----------------------------------FIM DOS ATRIBUTOS-----------------------------------	
	
//-----------------------------------CONSTRUTORES-----------------------------------	
	
public Midia(int id, String nome, String descricao, int tipo, int ativo){
		
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.tipo = tipo;
		this.ativo = ativo;
		
	}
	
	public Midia(){
		
		this(0,"","",0,0);
		
	}
	
//-----------------------------------FIM DOS CONSTRUTORES-----------------------------------	

//-----------------------------------GETTERS E SETTERS-----------------------------------	
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public int getAtivo() {
		return ativo;
	}

	public void setAtivo(int ativo) {
		this.ativo = ativo;
	}
	
//----------------------------------- FIM DOS GETTERS E SETTERS-----------------------------------	

}

//-----------------------------------FIM DA CLASSE MODELO-----------------------------------
