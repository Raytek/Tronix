﻿create database papercad;
use papercad;
DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(64) NOT NULL DEFAULT '',
  `login` varchar(64) NOT NULL DEFAULT '',  
  `senha` varchar(64) NOT NULL DEFAULT '',  
  `email` varchar(64) NOT NULL DEFAULT '',  
  `tipo` int(1) unsigned NOT NULL DEFAULT '2',
  `ativo` int(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;