﻿use papercad;
DROP TABLE IF EXISTS `midia`;
CREATE TABLE `midia` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(64) NOT NULL DEFAULT '',  
  `descricao` varchar(1024) NOT NULL DEFAULT '',  
  `tipo` int(1) unsigned NOT NULL DEFAULT '2',
  `ativo` int(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;