package br.edu.etec.hortolandia.papercad.dao;

import java.sql.*;

import javax.swing.JOptionPane;

import br.edu.etec.hortolandia.papercad.model.Usuario;


public class UsuarioDAO {

	/*
	 * Defini��o das informa��es necess�rias para conex�o a banco
	 */
	
	//Driver de conex�o ao MySQL
	private String servidor = "com.mysql.jdbc.Driver";
	//url que identifica o banco
	private String urlBanco = "jdbc:mysql://localhost:3306/papercad";
	//login de usu�rio no banco
	private String Banco = "root";
	//senha do usu�rio no banco
	//private String senhaBanco = "root";
	private String senhaBanco = "";
	
	//***M�todo de conexao
	public Connection conecta(){
		
		Connection con = null;
		
		try{
			
			Class.forName(servidor);
			con = DriverManager.getConnection(urlBanco, Banco, senhaBanco);
			
		}catch(ClassNotFoundException e){
			
			e.printStackTrace();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			
		}
		
		return con;
		
	}
	
	public void listar(){
		
		Connection con = conecta();
		
		try{
			
			Statement stmt = con.createStatement();
			String sql = "select * from usuario";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			String relacao = "Rela��o dos usuarios cadastrados \n";
			while(rs.next()){
				
				relacao = relacao + "\n Id: " + rs.getString(1).toString() + 
						" - Nome: " + rs.getString(2) + " - Login: " + rs.getString(3) + 
						" - Senha: " + rs.getString(4) + " - Email: " + rs.getString(5) + 
						" - Tipo: " + rs.getString(6).toString() + " - Ativo: " + rs.getString(7).toString();
				
			}
			
			rs.close();
			JOptionPane.showMessageDialog(null, relacao + "\n");
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			
			try{
				
				con.close();
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
	}
	
	public Usuario consultar(Usuario use){
		
		Connection con = conecta();
		try{
			
			Statement stmt = con.createStatement();
			String sql = "select * from usuario where id = " + use.getId();
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			try{
				
				use.setId(rs.getInt(1));
				use.setNome(rs.getString(2));
				use.setLogin(rs.getString(3));
				use.setSenha(rs.getString(4));
				use.setEmail(rs.getString(5));
				use.setTipo(rs.getInt(6));
				use.setAtivo(rs.getInt(7));
				
			}catch(Exception e){
				JOptionPane.showMessageDialog(null, "Usu�rio n�o encontrado.");
			}
			
			rs.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			
			try{
				
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
			
			return use;
		
		}
	
	public void incluir(Usuario use){
		
		Connection con = conecta();
		PreparedStatement ps = null;
		
		try{
			
			Statement stmt = con.createStatement();
			String sql = "select max(id) from usuario";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			int proximoId = rs.getInt(1) + 1;
			rs.close();
			String sqlInsert = "insert into usuario values(?, ?, ?, ?, ?, ?, ?);";
			ps = con.prepareStatement(sqlInsert);
			ps.setInt(1, proximoId);
			ps.setString(2, use.getNome());
			ps.setString(3, use.getLogin());
			ps.setString(4, use.getSenha());
			ps.setString(5, use.getEmail());
			ps.setInt(6, use.getTipo());
			ps.setInt(7, use.getAtivo());
			ps.executeUpdate();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			
		}finally{
			
			try{
				
				ps.close();
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
		
	}
	
	public void alterar(Usuario use){
		
		Connection con = conecta();
		PreparedStatement ps = null;
		
		try{
			
			String sqlUpdate = "update usuario set nome = ?, login = ?, senha = ?, " + 
								"email = ?, tipo = ?, ativo = ? where id = ?;";
			ps = con.prepareStatement(sqlUpdate);
			ps.setString(1, use.getNome());
			ps.setString(2, use.getLogin());
			ps.setString(3, use.getSenha());
			ps.setString(4, use.getEmail());
			ps.setString(5, Integer.toString(use.getTipo()));
			ps.setString(6, Integer.toString(use.getAtivo()));
			ps.setString(7, Integer.toString(use.getId()));
			ps.executeUpdate();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			
		}finally{
			
			try{
				
				ps.close();
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
		
	}
	
	public void excluir(Usuario use){
		
		Connection con = conecta();
		PreparedStatement ps = null;
		
		try{
			
			String sqlDelete = "update usuario set ativo = ? where id = ?;";
			
			ps = con.prepareStatement(sqlDelete);
			ps.setString(1, Integer.toString(use.getAtivo()));
			ps.setString(2, Integer.toString(use.getId()));
			ps.executeUpdate();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			
		}finally{
			
			try{
				
				ps.close();
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				
			}
			
		}
		
	}
	
	public String verificaLogin(Usuario use){
		
		Connection con = conecta();
		Statement s = null;
		String teste = "";
		
		try{
			
			String SQLLogin = "select * from usuario where login = '"+use.getLogin()+"' and senha = '"+use.getSenha()+"';";
			
			s = con.createStatement();  
			ResultSet rs = s.executeQuery(SQLLogin);
			
			if(rs.next() && rs.getInt("ativo") != 0){
				
				use.setTipo(rs.getInt("tipo"));
				use.setAtivo(rs.getInt("ativo"));
				use.setNome(rs.getString("nome"));
				teste += "true#";
				teste += use.getAtivo()+"#";
				teste += use.getTipo()+"#";
				teste += use.getNome()+"#";
				
			}else{
				JOptionPane.showMessageDialog(null, "Login e/ou Senha Incorretos.", "Falha na autentica��o",0);
				
				teste += "false#";
				teste += "0#";
				teste += "0#";
				teste += " #";
				
			}
			
			rs.close();
			
		}catch(SQLException e){
			
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e,"Erro no SQL",JOptionPane.ERROR_MESSAGE);
			
		}finally{
			
			try{
				
				s.close();
				con.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, e,"Erro ao fechar conex�o",JOptionPane.ERROR_MESSAGE);
				
			}
			
		}
		return teste;
		
	}
}
