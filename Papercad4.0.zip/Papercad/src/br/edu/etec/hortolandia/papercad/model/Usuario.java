package br.edu.etec.hortolandia.papercad.model;

//-----------------------------------CLASSE MODELO USUARIO-----------------------------------

public class Usuario {

//-----------------------------------ATRIBUTOS-----------------------------------	
	
	private String nome, login, senha, email;
	private int id, tipo, ativo;
	
//-----------------------------------FIM DOS ATRIBUTOS-----------------------------------	
	
//-----------------------------------CONSTRUTORES-----------------------------------	
	public Usuario(int id, String nome, String login, String senha, String email, int tipo, int ativo){
		
		this.id = id;
		this.nome = nome;
		this.login = login;
		this.senha = senha;
		this.email = email;
		this.tipo = tipo;
		this.ativo = ativo;
		
	}
	
	public Usuario(){
		
		this(0,"","","","",0,0);
		
	}
	
//-----------------------------------FIM DOS CONSTRUTORES-----------------------------------	

//-----------------------------------GETTERS E SETTERS-----------------------------------	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAtivo() {
		return ativo;
	}

	public void setAtivo(int ativo) {
		this.ativo = ativo;
	}
	
	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
//-----------------------------------FIM DOS GETTERS E SETTERS-----------------------------------	
	
}

//-----------------------------------FIM DA CLASSE MODELO-----------------------------------
