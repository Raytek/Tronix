package br.edu.etec.hortolandia.papercad.view;
import java.awt.*;

import javax.swing.*;

public class Splash extends JFrame {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    JProgressBar barra;
    String mensagem = "Desenvolvido por Vin�cius Savi Silva, Junho de 2012";

    public void showSplash() throws InterruptedException {        
    	
		this.setLayout(null);
		this.setUndecorated(true);
		this.setLocationRelativeTo(null);
		getContentPane().setBackground(new Color(0,0,0));
		
		Toolkit kit = Toolkit.getDefaultToolkit();  
    	Image img = kit.getImage("pen.png");
    	this.setIconImage(img);
        
        // Configura a posi��o e o tamanho da janela
        int width = 380;
        int height = 290;
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screen.width-width)/2;
        int y = (screen.height-height)/2;
        setBounds(x,y,width,height);
        
        // Constr�i o splash screen
        //Coluna, Linha , Largura e Altura
        JLabel label = new JLabel(new ImageIcon("jornal.jpg"));
        label.setBounds(0, -20, 380, 300);
        final JLabel copyrt = new JLabel(mensagem);
        copyrt.setFont(new Font("Verdana", Font.BOLD, 8));
        copyrt.setForeground( new Color(255,255,255));
        copyrt.setBounds(70, 270, 380, 20);
        
        setVisible(true);
        
        
        barra = new JProgressBar();
		barra.setBackground(new Color(54,54,54));
		barra.setStringPainted(true);
		barra.setBounds(10, 250, 360, 20);
		
		this.add(label);
		this.add(copyrt);
		this.add(barra);
		
		new Thread(){
			
			public void run(){
				
				for(int p = 0;p < 101;p++){
					
					if(p >= 20 && p <= 40){
						
						copyrt.setText(mensagem = "Iniciando a alica��o...");
						
					}
					
					if(p >= 41 && p <= 60){
						
						copyrt.setText(mensagem = "Carregando m�dulos...");
						
					}
					
					if(p >= 61 && p <= 80){
						
						copyrt.setText(mensagem = "Carregando interface gr�fica...");
						
					}
					
					if(p >= 81 && p <= 100){
						
						copyrt.setText(mensagem = "Aplica��o totalmente carregada...");
						
					}
					

					try{
					
					barra.setValue(p);
					sleep(80);
					
					}catch(InterruptedException e){
						
						e.printStackTrace();
						
					}
					
				
				}
				
			}
			
		}.start();
		Thread.sleep(9500);
		
		this.setVisible(false);
    }
    
    public void showSplashAndExit() throws InterruptedException {        
        showSplash();
        this.dispose();        
    }
    
    public static void main(String[] args) throws InterruptedException {        
        
        Splash splash = new Splash();
        splash.showSplashAndExit(); 
        new Login();
    }
}
