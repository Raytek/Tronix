package br.edu.etec.hortolandia.papercad.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

import br.edu.etec.hortolandia.papercad.dao.UsuarioDAO;
import br.edu.etec.hortolandia.papercad.model.Usuario;
import br.edu.etec.hortolandia.papercad.view.Tela;

public class Login extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton btnLogin,btnLimpar, btnSair;
	JTextField txtLogin;
	JPasswordField txtSenha;
	
	Usuario user = new Usuario();
	UsuarioDAO use = new UsuarioDAO();
	
	public Login()
	{
		this.setTitle("Login");
		this.setSize(350,170);
		this.setLayout(null);
		this.setUndecorated(true);
		this.setLocationRelativeTo(null);  
        getContentPane().setBackground(new Color(230,230,250));
		
        Toolkit kit = Toolkit.getDefaultToolkit();  
    	Image img = kit.getImage("pen.png");
    	this.setIconImage(img);
        
		//Coluna, linha, largura e altura.
		JLabel usuario = new JLabel("Login: ");
		usuario.setBounds(10,30,80,20);
		JLabel senha = new JLabel("Senha: ");
		senha.setBounds(10,50,80,20);
		
		txtLogin = new JTextField();
		txtLogin.setBounds(60,30,270,20);
		txtSenha = new JPasswordField();
		txtSenha.setBounds(60,50,270,20);
		
		btnLogin = new JButton("Logar");
		btnLogin.setBounds(10,100,100,20);
		btnLogin.addActionListener(this);
		btnLimpar = new JButton("Limpar");
		btnLimpar.setBounds(120,100,100,20);
		btnLimpar.addActionListener(this);
		btnSair = new JButton("Sair");
		btnSair.setBounds(230,100,100,20);
		btnSair.addActionListener(this);
		
		this.add(senha);
		this.add(usuario);
		this.add(txtLogin);
		this.add(txtSenha);
		this.add(btnLimpar);
		this.add(btnLogin);
		this.add(btnSair);
		
		this.setVisible(true);
	}
	
	String teste = "", nome = "";
	String [] temp = null;
	boolean aut = false;
	int ativo = 0;
	int tipo = 0;
	
	
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	try{	
		
		if(e.getSource() == btnLogin)
		{
		
			user.setLogin(txtLogin.getText());
			user.setSenha(txtSenha.getText());
			teste = use.verificaLogin(user);
			
			temp = teste.split("#");
			
			aut = Boolean.parseBoolean(temp[0]);
			ativo = Integer.parseInt(temp[1]);
			tipo = Integer.parseInt(temp[2]);
			nome = temp[3];
			
			if(aut == true){
				
				this.dispose();
				new Tela(ativo, tipo, nome);
			}

		}else{
			if(e.getSource() == btnLimpar)
			{
				txtLogin.setText(null);
				txtSenha.setText(null);
			}else{
				if(e.getSource() == btnSair)
				{
					int resposta = JOptionPane.showConfirmDialog(null,"Deseja sair?", "Sair",JOptionPane.WARNING_MESSAGE, JOptionPane.YES_NO_OPTION, new ImageIcon("sair.png"));  
					if(resposta == JOptionPane.YES_OPTION){ 
						System.exit(0);
					}
				}
			}
		}
	}catch(Exception e1){
		
		e1.printStackTrace();
		JOptionPane.showMessageDialog(null, e1,"Erro no Login()",0);
		
	}
		
	}

}